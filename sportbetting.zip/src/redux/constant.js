export const SET_BETLIST = "SET_BETLIST"
export const SET_SPORTSBOOK = "SET_SPORTSBOOK"
export const SET_DATE = "SET_DATE"
export const SET_SPORTLIST = "SET_SPORTLIST"

export const SET_USERDATA = "SET_USERDATA";
export const SET_PROFILE = "SET_PROFILE";
export const SET_PROFILEINFO = "SET_PROFILEINFO"
export const LOGOUT = "LOGOUT";

export const SET_WATCHLIST = "SET_WATCHLIST"

export const SET_ALERT = "SET_ALERT";

export const SET_FAVOURITE = "SET_FAVOURITE"