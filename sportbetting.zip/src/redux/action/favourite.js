import {SET_FAVOURITE} from '../constant'

export function setfavourites(data)
{
    return {type:SET_FAVOURITE,data}
}